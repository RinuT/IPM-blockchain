package com.example.schedulerdemo;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

import org.apache.commons.io.FileUtils;
import org.json.CDL;
import org.json.JSONArray;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

@Component
public class ScheduledTasks {

	private static final Logger logger = LoggerFactory.getLogger(ScheduledTasks.class);
	private static final DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("HH:mm:ss");

	/**
	 * schedule method to be executed in fixed time interval (eg:12 am every day)
	 * http://www.quartz-scheduler.org/documentation/quartz-2.x/tutorials/crontrigger.html
	 * -->use this to understand cron
	 */

	@Scheduled(cron = "* * * ? * *")
	public void scheduleTask() {

		final String uri = "https://gturnquist-quoters.cfapps.io/api/random";

		/*RestTemplate restTemplate = new RestTemplate();
		String jsonString = restTemplate.getForObject(uri, String.class);*/
		String jsonString = "{\"fileName\": [{\"name\": \"Anand\",\"last\": \"Dwivedi\",\"place\": \"Bangalore\"}]}";

		JSONObject output;
		try {
			output = new JSONObject(jsonString);

			//JSONArray jsonArray = new JSONArray();
			JSONArray jsonArray=output.getJSONArray("fileName");
			String fileName = "src/main/resources/sample.csv";
			FileWriter writer = new FileWriter(fileName);
			String csv = CDL.toString(jsonArray);
			writer.write(csv);
			writer.close();
			System.out.println("Data has been Sucessfully Written to " + fileName);
		} catch (Exception e) {
			e.printStackTrace();
		}
		logger.info("Fixed Rate Task :: Execution Time - {}", dateTimeFormatter.format(LocalDateTime.now()));
	}

}
