package com.example.schedulerdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication
@EnableScheduling
public class SchedulerDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(SchedulerDemoApplication.class, args);
	}
	
}

/*https://www.callicoder.com/spring-boot-quartz-scheduler-email-scheduling-example/
 * this is just a basic scheduler. you van use tis link to add emailing jobs. as far as i understood you dont need a 
 * rest controller for this app. So i created a scheduling background app. add he implementation for emailing job for this. wont take much 
 * time.
 * Happy COding :*
 */